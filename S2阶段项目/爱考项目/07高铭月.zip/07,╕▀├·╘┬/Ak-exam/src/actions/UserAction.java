package actions;

import beans.Accounts;
import beans.Actions;
import dao.AccountsDao;
import dao.ActionsDao;
import dao.RolesDao;

import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {
	private Accounts account;
	private String action;
	
	public String login() {
		int aid = AccountsDao.login(account);
		if (aid != 0) {
			Map<String, Object> session = ActionContext.getContext().getSession();
			List<Actions> actions = ActionsDao.getActionsByType(account.getRoles().getRid());
			account.getRoles().setRname(RolesDao.getRolesName(account.getRoles()));
			account.setAid(aid);
			session.put("login_user", account);
			session.put("actions", actions);
			return "login_success";
		}
		this.addFieldError("error", "登录失败，请核实！");
		return "login_fail";
	}
	
	public String loginOut() {
		Map<String, Object> session = ActionContext.getContext().getSession();
		if (session != null) {
			session.remove("login_user");
			session.remove("actions");
			if ("exit".equals(action)) {
				session.put("login_status", "exit");
			}
		}
		return "loginOut";
	}

	public Accounts getAccount() {
		return account;
	}

	public void setAccount(Accounts account) {
		this.account = account;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
	
}
