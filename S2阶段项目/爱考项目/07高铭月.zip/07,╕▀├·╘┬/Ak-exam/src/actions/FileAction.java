package actions;

import java.io.File;
import java.io.IOException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.exceptions.NotOfficeXmlFileException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.opensymphony.xwork2.ActionSupport;
import beans.Questions;
import beans.Tests;
import dao.LevelsDao;
import dao.QuestionsDao;

public class FileAction extends ActionSupport {
	private File file;
	private Integer qtid;
	private Integer success_num;
	private Integer total_num;
	private Integer errorType;
	
	public String uploadExcel () {
		success_num = 0;
		total_num = 0;
		XSSFWorkbook workbook = null;
		try {
			workbook = new XSSFWorkbook(file);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
//			e.printStackTrace();
			errorType = 2;
			return "upload_excel_fail";
		} catch (NotOfficeXmlFileException e) {
			errorType = 1;
			return "upload_excel_fail";
		}
		
		if (workbook == null) {
			System.out.println("null");
			return "upload_excel_fail";
		}
		for (int i = 0;i < workbook.getNumberOfSheets();i++) {
			XSSFSheet sheet = workbook.getSheetAt(i);
			int nowRow = 0;
			for (Row row : sheet) {
				++nowRow;
				Questions question = new Questions();
				if (nowRow == 1) {
					if (!"类型".equals(row.getCell(0).getStringCellValue())) {
						errorType = 3;
						return "upload_excel_fail";
					}
					
					if (!"题目内容".equals(row.getCell(1).getStringCellValue())) {
						errorType = 3;
						return "upload_excel_fail";
					}
					
					if (!"选项A".equals(row.getCell(2).getStringCellValue())) {
						errorType = 3;
						return "upload_excel_fail";
					}
					
					if (!"选项B".equals(row.getCell(3).getStringCellValue())) {
						errorType = 3;
						return "upload_excel_fail";
					}
					
					if (!"选项C".equals(row.getCell(4).getStringCellValue())) {
						errorType = 3;
						return "upload_excel_fail";
					}
					
					if (!"选项D".equals(row.getCell(5).getStringCellValue())) {
						errorType = 3;
						return "upload_excel_fail";
					}
					
					if (!"答案".equals(row.getCell(6).getStringCellValue())) {
						errorType = 3;
						return "upload_excel_fail";
					}
					
					if (!"难度".equals(row.getCell(7).getStringCellValue())) {
						errorType = 3;
						return "upload_excel_fail";
					}
					
					if (!"对应章节".equals(row.getCell(8).getStringCellValue())) {
						errorType = 3;
						return "upload_excel_fail";
					}
				}else {
					if (row.getCell(0).getStringCellValue().equals("单选")) {
						question.setQtype(1);
					}else if (row.getCell(0).getStringCellValue().equals("多选")) {
						question.setQtype(2);
					}
					
					question.setQname(row.getCell(1).getStringCellValue());
					question.setQta(row.getCell(2).getStringCellValue());
					question.setQtb(row.getCell(3).getStringCellValue());
					question.setQtc(row.getCell(4).getStringCellValue());
					question.setQtd(row.getCell(5).getStringCellValue());
					
					if (row.getCell(6).getStringCellValue().indexOf("A") != -1) {
						question.setQa(1);
					}else {
						question.setQa(0);
					}
					
					if (row.getCell(6).getStringCellValue().indexOf("B") != -1) {
						question.setQb(1);
					}else {
						question.setQb(0);
					}
					
					if (row.getCell(6).getStringCellValue().indexOf("C") != -1) {
						question.setQc(1);
					}else {
						question.setQc(0);
					}
					
					if (row.getCell(6).getStringCellValue().indexOf("D") != -1) {
						question.setQd(1);
					}else {
						question.setQd(0);
					}
					question.setLevels(LevelsDao.getLevelsByLname(row.getCell(7).getStringCellValue()));
					question.setQchapter(row.getCell(8).getStringCellValue());
					
					Tests test = new Tests();
					test.setTid(qtid);
					question.setTests(test);
					
					if (QuestionsDao.saveQuestion(question)) {
						success_num ++;
					}
					total_num++;
				}
			}
			
		}
		try {
			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		if (success_num != 0) {
			return "upload_excel_success";
		}
		
		return "upload_excel_fail";
	}
	public File getFile() {
		return file;
	}
	public void setFile(File file) {
		this.file = file;
	}
	public Integer getQtid() {
		return qtid;
	}
	public void setQtid(Integer qtid) {
		this.qtid = qtid;
	}
	public Integer getSuccess_num() {
		return success_num;
	}
	public void setSuccess_num(Integer success_num) {
		this.success_num = success_num;
	}
	public Integer getTotal_num() {
		return total_num;
	}
	public void setTotal_num(Integer total_num) {
		this.total_num = total_num;
	}
	public Integer getErrorType() {
		return errorType;
	}
	public void setErrorType(Integer errorType) {
		this.errorType = errorType;
	}
}
