package actions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import com.opensymphony.xwork2.ActionSupport;

import beans.Classs;
import beans.Questions;
import beans.TestPapers;
import beans.TestPapersClass;
import beans.TestPapersPapers;
import beans.Tests;
import dao.QuestionsDao;
import dao.TestPapersClassDao;
import dao.TestPapersDao;
import dao.TestPapersPapersDao;

public class PapersAction extends ActionSupport {
	private Integer testType;    //笔试、机试
	private Integer testStatus;  //未开考、考试中、考试结束
	private String addStatus;
	private List<TestPapers> testPapersList;
	private Tests tests;
	private TestPapers testPapers;
	
	private Integer totalScore;
	private Integer singleSimple;
	private Integer singleNormal;
	private Integer singleHard;
	private Integer manySimple;
	private Integer manyNormal;
	private Integer manyHard;
	private Integer totalSubject;
	private Float everyScore;
	private List<Integer> chooseBox;
	private List<String> estart;
	private List<Integer> classs;
	
	public String query () {
		testPapersList = TestPapersDao.getTestPapers(testType, testStatus);
		return "papers_query";
	}
	
	public String start () {
		List<Long> times = new ArrayList<Long>();
		for (String s : estart) {
			Date date = null;
			try {
				date = new SimpleDateFormat("yyyy年MM月dd日HH时mm分").parse(s);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			if (date != null) {
				times.add(date.getTime());
			}else {
				addStatus = "填写的时间错误！";
				return "papers_start";
			}
		}
		System.out.println("classs:" + classs);
		System.out.println("estart:" + estart);
		
		for (int i = 0;i < classs.size();i++) {
			TestPapersClass temp = new TestPapersClass();
			temp.setTestPapers(testPapers);
			Classs tempClasss = new Classs();
			tempClasss.setCid(classs.get(i));
			temp.setClasss(tempClasss);
			temp.setCstart(times.get(i));
			if (!TestPapersClassDao.saveTestPapersClass(temp)) {
				addStatus = "开始考试失败！未能保存班级！";
				return "papers_start";
			}
		}
		Collections.sort(times);
		testPapers = TestPapersDao.getTestPaperByEid(testPapers.getEid());
		if (testPapers == null) {
			addStatus = "开始考试失败！读取失败！";
			return "papers_start";
		}
		
		testPapers.setEstart(times.get(0));
		if (!TestPapersDao.editTestPaper(testPapers)) {
			addStatus = "开始考试失败！未能保存主时间！";
			return "papers_start";
		}
		addStatus = "开始考试成功！";
		return "papers_start";
	}
	
	public String addChoose () {
		if (tests.getTid() == null || tests.getTid() == 0) {
			addStatus = "您没有选定科目！";
			return "papers_addChoose";
		}
		
		if (addTestPapersPapers(chooseBox)) {
			addStatus = "选题组卷成功！！！";
		}else {
			addStatus = "选题组卷失败！！！";
		}
		return "papers_addChoose";
	}
	
	public String addRandom () {
		if (tests.getTid() == null || tests.getTid() == 0) {
			addStatus = "您没有选定科目！";
			return "papers_addRandom";
		}
		List<Questions> questions = QuestionsDao.getQuestionsByQtid(tests.getTid());
		HashMap<Integer, HashMap<Integer, List<Integer>>> map = new HashMap<Integer, HashMap<Integer,List<Integer>>>();
		//类别（HashMap、type）→难度（HashMap、level）→题目（List）
		for (Questions question : questions) {
			if (map.get(question.getQtype()) == null) {
				map.put(question.getQtype(), new HashMap<Integer, List<Integer>>());
			}
			HashMap<Integer, List<Integer>> levels = map.get(question.getQtype());
			if (levels.get(question.getLevels().getLid()) == null) {
				levels.put(question.getLevels().getLid(), new ArrayList<Integer>());
			}
			List<Integer> tempList = levels.get(question.getLevels().getLid());
			tempList.add(question.getQid());
			levels.put(question.getLevels().getLid(), tempList);
			map.put(question.getQtype(), levels);
		}
		addStatus = "";
		if (singleSimple != null) {
			if (map.get(1) != null) {
				if (map.get(1).get(1) != null) {
					if (singleSimple > map.get(1).get(1).size()) {
						addStatus = addStatus + "单选题中的简单题超过题库数量！应等于或少于 " + map.get(1).get(1).size() + " 道题！n";
					}
				}else if (singleSimple != 0) {
					addStatus = addStatus + "题库中不存在单选题的简单题！n";
				}
			}else if (singleSimple != 0) {
				addStatus = addStatus + "题库中不存在单选题的简单题！n";
			}
		}
		
		if (singleNormal != null) {
			if (map.get(1) != null) {
				if (map.get(1).get(2) != null) {
					if (singleNormal > map.get(1).get(2).size()) {
						addStatus = addStatus + "单选题中的一般题超过题库数量！应等于或少于 " + map.get(1).get(2).size() + " 道题！n";
					}
				}else if (singleNormal != 0) {
					addStatus = addStatus + "题库中不存在单选题的一般题！n";
				}
			}else if (singleNormal != 0) {
				addStatus = addStatus + "题库中不存在单选题的一般题！n";
			}
		}
		
		if (singleHard != null) {
			if (map.get(1) != null) {
				if (map.get(1).get(3) != null) {
					if (singleHard > map.get(1).get(3).size()) {
						addStatus = addStatus + "单选题中的困难题超过题库数量！应等于或少于 " + map.get(1).get(3).size() + " 道题！n";
					}
				}else if (singleHard != 0){
					addStatus = addStatus + "题库中不存在单选题的困难题！n";
				}
			}else if (singleHard != 0) {
				addStatus = addStatus + "题库中不存在单选题的困难题！n";
			}
		}
		
		if (manySimple != null) {
			if (map.get(2) != null) {
				if (map.get(2).get(1) != null) {
					if (manySimple > map.get(2).get(1).size()) {
						addStatus = addStatus + "多选题中的简单题超过题库数量！应等于或少于 " + map.get(2).get(1).size() + " 道题！n";
					}
				}else if (manySimple != 0) {
					addStatus = addStatus + "题库中不存在多选题的简单题！n";
				}
			}else if (manySimple != 0){
				addStatus = addStatus + "题库中不存在多选题的简单题！n";
			}
		}
		
		if (manyNormal != null) {
			if (map.get(2) != null) {
				if (map.get(2).get(2) != null) {
					if (manyNormal > map.get(2).get(2).size()) {
						addStatus = addStatus + "多选题中的一般题超过题库数量！应等于或少于 " + map.get(2).get(2).size() + " 道题！n";
					}
				}else if (manyNormal != 0) {
					addStatus = addStatus + "题库中不存在多选题的一般题！n";
				}
			}else if (manyNormal != 0) {
				addStatus = addStatus + "题库中不存在多选题的一般题！n";
			}
		}
		
		if (manyHard != null) {
			if (map.get(2) != null) {
				if (map.get(2).get(3) != null) {
					if (manyHard > map.get(2).get(3).size()) {
						addStatus = addStatus + "多选题中的困难题超过题库数量！应等于或少于 " + map.get(2).get(3).size() + " 道题！";
					}
				}else if (manyHard != 0) {
					addStatus = addStatus + "题库中不存在多选题的困难题！";
				}
			}else if (manyHard != 0) {
				addStatus = addStatus + "题库中不存在多选题的困难题！";
			}
		}
		
		if (!"".equals(addStatus)) {
			return "papers_addRandom";
		}
		
		List<Integer> list = new ArrayList<Integer>();
		
		if (singleSimple != null && singleSimple != 0) {
			if (singleSimple != map.get(1).get(1).size()) {
				List<Integer> temp = getRandoms(0, map.get(1).get(1).size() - 1, singleSimple);
				for (int t : temp) {
					list.add(map.get(1).get(1).get(t));
				}
			}else if (singleSimple == map.get(1).get(1).size()){
				for (int t : map.get(1).get(1)) {
					list.add(t);
				}
			}
		}
		
		if (singleNormal != null && singleNormal != 0) {
			if (singleNormal != map.get(1).get(2).size()) {
				List<Integer> temp = getRandoms(0, map.get(1).get(2).size() - 1, singleNormal);
				for (int t : temp) {
					list.add(map.get(1).get(2).get(t));
				}
			}else if (singleNormal == map.get(1).get(2).size()){
				for (int t : map.get(1).get(2)) {
					list.add(t);
				}
			}
		}
		
		if (singleHard != null && singleHard != 0) {
			if (singleHard != map.get(1).get(3).size()) {
				List<Integer> temp = getRandoms(0, map.get(1).get(3).size() - 1, singleHard);
				for (int t : temp) {
					list.add(map.get(1).get(3).get(t));
				}
			}else if (singleHard == map.get(1).get(3).size()){
				for (int t : map.get(1).get(3)) {
					list.add(t);
				}
			}
		}
		
		if (manySimple != null && manySimple != 0) {
			if (manySimple != map.get(2).get(1).size()) {
				List<Integer> temp = getRandoms(0, map.get(2).get(1).size() - 1, manySimple);
				for (int t : temp) {
					list.add(map.get(2).get(1).get(t));
				}
			}else if (manySimple == map.get(2).get(1).size()){
				for (int t : map.get(2).get(1)) {
					list.add(t);
				}
			}
		}
		
		if (manyNormal != null && manyNormal != 0) {
			if (manyNormal != map.get(2).get(2).size()) {
				List<Integer> temp = getRandoms(0, map.get(2).get(2).size() - 1, manyNormal);
				for (int t : temp) {
					list.add(map.get(2).get(2).get(t));
				}
			}else if (manyNormal == map.get(2).get(2).size()){
				for (int t : map.get(2).get(2)) {
					list.add(t);
				}
			}
		}
		
		if (manyHard != null && manyHard != 0) {
			if (manyHard != map.get(2).get(3).size()) {
				List<Integer> temp = getRandoms(0, map.get(2).get(3).size() - 1, manyHard);
				for (int t : temp) {
					list.add(map.get(2).get(3).get(t));
				}
			}else if (manyHard == map.get(2).get(3).size()){
				for (int t : map.get(2).get(3)) {
					list.add(t);
				}
			}
		}
		
		if (addTestPapersPapers(list)) {
			addStatus = "随机组卷成功！！！";
		}else {
			addStatus = "随机组卷失败！！！";
		}
		
		return "papers_addRandom";
	}
	
	private boolean addTestPapersPapers (List<Integer> list) {
		testPapers.setTests(tests);
		testPapers.setEtime(testPapers.getEtime() * 60000);
		testPapers = TestPapersDao.saveTestPapers(testPapers);
		if (testPapers.getEid() > 0) {
			int successCount = 0;
			for (int temp : list) {
				TestPapersPapers testPapersPapers = new TestPapersPapers();
				Questions q = new Questions();
				q.setQid(temp);
				testPapersPapers.setTestPapers(testPapers);
				testPapersPapers.setQuestions(q);
				if (TestPapersPapersDao.saveTestPapersPapers(testPapersPapers)) {
					successCount++;
				}
			}
			
			if (successCount == list.size()) {
				return true;
			}else {
				return false;
			}
		}else {
			return false;
		}
	}
	
	private List<Integer> getRandoms (int min,int max,int t) {
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0;i < t;i++) {
			int temp = getRandom(min, max);
			if (i == 0) {
				list.add(getRandom(min, max));
			}
			while (!checkUnique(list, temp)) {
				temp = getRandom(min, max);
			}
			if (i != 0) {
				list.add(temp);
			}
		}
		return list;
	}
	
	private int getRandom (int min,int max) {
		return (int)(min + Math.random() * (max - min + max));
	}
	
	private boolean checkUnique (List<Integer> list,int n) {
		for (int t : list) {
			if (t == n) {
				return false;
			}
		}
		return true;
	}

	public Integer getTestType() {
		return testType;
	}

	public void setTestType(Integer testType) {
		this.testType = testType;
	}

	public Integer getTestStatus() {
		return testStatus;
	}

	public void setTestStatus(Integer testStatus) {
		this.testStatus = testStatus;
	}

	public String getAddStatus() {
		return addStatus;
	}

	public void setAddStatus(String addStatus) {
		this.addStatus = addStatus;
	}

//	public Integer getSubject() {
//		return subject;
//	}
//
//	public void setSubject(Integer subject) {
//		this.subject = subject;
//	}

	public Integer getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(Integer totalScore) {
		this.totalScore = totalScore;
	}

	public Integer getSingleSimple() {
		return singleSimple;
	}

	public void setSingleSimple(Integer singleSimple) {
		this.singleSimple = singleSimple;
	}

	public Integer getSingleNormal() {
		return singleNormal;
	}

	public void setSingleNormal(Integer singleNormal) {
		this.singleNormal = singleNormal;
	}

	public Integer getSingleHard() {
		return singleHard;
	}

	public void setSingleHard(Integer singleHard) {
		this.singleHard = singleHard;
	}

	public Integer getManySimple() {
		return manySimple;
	}

	public void setManySimple(Integer manySimple) {
		this.manySimple = manySimple;
	}

	public Integer getManyNormal() {
		return manyNormal;
	}

	public void setManyNormal(Integer manyNormal) {
		this.manyNormal = manyNormal;
	}

	public Integer getManyHard() {
		return manyHard;
	}

	public void setManyHard(Integer manyHard) {
		this.manyHard = manyHard;
	}

	public Integer getTotalSubject() {
		return totalSubject;
	}

	public void setTotalSubject(Integer totalSubject) {
		this.totalSubject = totalSubject;
	}

	public Float getEveryScore() {
		return everyScore;
	}

	public void setEveryScore(Float everyScore) {
		this.everyScore = everyScore;
	}

	public Tests getTests() {
		return tests;
	}

	public void setTests(Tests tests) {
		this.tests = tests;
	}

	public List<TestPapers> getTestPapersList() {
		return testPapersList;
	}

	public void setTestPapersList(List<TestPapers> testPapersList) {
		this.testPapersList = testPapersList;
	}

	public TestPapers getTestPapers() {
		return testPapers;
	}

	public void setTestPapers(TestPapers testPapers) {
		this.testPapers = testPapers;
	}

	public List<Integer> getChooseBox() {
		return chooseBox;
	}

	public void setChooseBox(List<Integer> chooseBox) {
		this.chooseBox = chooseBox;
	}

	public List<Integer> getClasss() {
		return classs;
	}

	public void setClasss(List<Integer> classs) {
		this.classs = classs;
	}

	public List<String> getEstart() {
		return estart;
	}

	public void setEstart(List<String> estart) {
		this.estart = estart;
	}
	
}
