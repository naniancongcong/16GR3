package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Directions entity. @author MyEclipse Persistence Tools
 */

public class Directions implements java.io.Serializable {

	// Fields

	private Integer did;
	private String dname;
	private Set stageses = new HashSet(0);
	private Set studentses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Directions() {
	}

	/** minimal constructor */
	public Directions(String dname) {
		this.dname = dname;
	}

	/** full constructor */
	public Directions(String dname, Set stageses, Set studentses) {
		this.dname = dname;
		this.stageses = stageses;
		this.studentses = studentses;
	}

	// Property accessors

	public Integer getDid() {
		return this.did;
	}

	public void setDid(Integer did) {
		this.did = did;
	}

	public String getDname() {
		return this.dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public Set getStageses() {
		return this.stageses;
	}

	public void setStageses(Set stageses) {
		this.stageses = stageses;
	}

	public Set getStudentses() {
		return this.studentses;
	}

	public void setStudentses(Set studentses) {
		this.studentses = studentses;
	}

}