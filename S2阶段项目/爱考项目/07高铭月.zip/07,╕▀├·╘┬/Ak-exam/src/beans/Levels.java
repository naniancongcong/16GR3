package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Levels entity. @author MyEclipse Persistence Tools
 */

public class Levels implements java.io.Serializable {

	// Fields

	private Integer lid;
	private String lname;
	private Set questionses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Levels() {
	}

	/** minimal constructor */
	public Levels(String lname) {
		this.lname = lname;
	}

	/** full constructor */
	public Levels(String lname, Set questionses) {
		this.lname = lname;
		this.questionses = questionses;
	}

	// Property accessors

	public Integer getLid() {
		return this.lid;
	}

	public void setLid(Integer lid) {
		this.lid = lid;
	}

	public String getLname() {
		return this.lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public Set getQuestionses() {
		return this.questionses;
	}

	public void setQuestionses(Set questionses) {
		this.questionses = questionses;
	}

}