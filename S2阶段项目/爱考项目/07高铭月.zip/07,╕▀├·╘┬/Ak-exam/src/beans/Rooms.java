package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Rooms entity. @author MyEclipse Persistence Tools
 */

public class Rooms implements java.io.Serializable {

	// Fields

	private Integer rid;
	private String rname;
	private Set studentses = new HashSet(0);
	private Set doorses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Rooms() {
	}

	/** minimal constructor */
	public Rooms(String rname) {
		this.rname = rname;
	}

	/** full constructor */
	public Rooms(String rname, Set studentses, Set doorses) {
		this.rname = rname;
		this.studentses = studentses;
		this.doorses = doorses;
	}

	// Property accessors

	public Integer getRid() {
		return this.rid;
	}

	public void setRid(Integer rid) {
		this.rid = rid;
	}

	public String getRname() {
		return this.rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	public Set getStudentses() {
		return this.studentses;
	}

	public void setStudentses(Set studentses) {
		this.studentses = studentses;
	}

	public Set getDoorses() {
		return this.doorses;
	}

	public void setDoorses(Set doorses) {
		this.doorses = doorses;
	}

}