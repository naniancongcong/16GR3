package beans;

/**
 * Doors entity. @author MyEclipse Persistence Tools
 */

public class Doors implements java.io.Serializable {

	// Fields

	private Integer did;
	private Rooms rooms;
	private Integer rdid;

	// Constructors

	/** default constructor */
	public Doors() {
	}

	/** full constructor */
	public Doors(Rooms rooms, Integer rdid) {
		this.rooms = rooms;
		this.rdid = rdid;
	}

	// Property accessors

	public Integer getDid() {
		return this.did;
	}

	public void setDid(Integer did) {
		this.did = did;
	}

	public Rooms getRooms() {
		return this.rooms;
	}

	public void setRooms(Rooms rooms) {
		this.rooms = rooms;
	}

	public Integer getRdid() {
		return this.rdid;
	}

	public void setRdid(Integer rdid) {
		this.rdid = rdid;
	}

}