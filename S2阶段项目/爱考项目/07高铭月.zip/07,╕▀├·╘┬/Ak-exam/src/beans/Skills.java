package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Skills entity. @author MyEclipse Persistence Tools
 */

public class Skills implements java.io.Serializable {

	// Fields

	private Integer sid;
	private String sname;
	private Set studentses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Skills() {
	}

	/** minimal constructor */
	public Skills(String sname) {
		this.sname = sname;
	}

	/** full constructor */
	public Skills(String sname, Set studentses) {
		this.sname = sname;
		this.studentses = studentses;
	}

	// Property accessors

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Set getStudentses() {
		return this.studentses;
	}

	public void setStudentses(Set studentses) {
		this.studentses = studentses;
	}

}