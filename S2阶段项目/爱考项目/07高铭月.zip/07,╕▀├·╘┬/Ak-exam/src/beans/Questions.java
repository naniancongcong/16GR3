package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Questions entity. @author MyEclipse Persistence Tools
 */

public class Questions implements java.io.Serializable {

	// Fields

	private Integer qid;
	private Tests tests;
	private Levels levels;
	private Integer qtype;
	private String qname;
	private Integer qa;
	private Integer qb;
	private Integer qc;
	private Integer qd;
	private String qchapter;
	private String qta;
	private String qtb;
	private String qtc;
	private String qtd;
	private Set testPapersAnswerses = new HashSet(0);
	private Set testPapersPaperses = new HashSet(0);
	private Set paperses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Questions() {
	}

	/** minimal constructor */
	public Questions(Tests tests, Levels levels, Integer qtype, String qname, Integer qa, Integer qb, Integer qc,
			Integer qd, String qchapter, String qta, String qtb, String qtc, String qtd) {
		this.tests = tests;
		this.levels = levels;
		this.qtype = qtype;
		this.qname = qname;
		this.qa = qa;
		this.qb = qb;
		this.qc = qc;
		this.qd = qd;
		this.qchapter = qchapter;
		this.qta = qta;
		this.qtb = qtb;
		this.qtc = qtc;
		this.qtd = qtd;
	}

	/** full constructor */
	public Questions(Tests tests, Levels levels, Integer qtype, String qname, Integer qa, Integer qb, Integer qc,
			Integer qd, String qchapter, String qta, String qtb, String qtc, String qtd, Set testPapersAnswerses,
			Set testPapersPaperses, Set paperses) {
		this.tests = tests;
		this.levels = levels;
		this.qtype = qtype;
		this.qname = qname;
		this.qa = qa;
		this.qb = qb;
		this.qc = qc;
		this.qd = qd;
		this.qchapter = qchapter;
		this.qta = qta;
		this.qtb = qtb;
		this.qtc = qtc;
		this.qtd = qtd;
		this.testPapersAnswerses = testPapersAnswerses;
		this.testPapersPaperses = testPapersPaperses;
		this.paperses = paperses;
	}

	// Property accessors

	public Integer getQid() {
		return this.qid;
	}

	public void setQid(Integer qid) {
		this.qid = qid;
	}

	public Tests getTests() {
		return this.tests;
	}

	public void setTests(Tests tests) {
		this.tests = tests;
	}

	public Levels getLevels() {
		return this.levels;
	}

	public void setLevels(Levels levels) {
		this.levels = levels;
	}

	public Integer getQtype() {
		return this.qtype;
	}

	public void setQtype(Integer qtype) {
		this.qtype = qtype;
	}

	public String getQname() {
		return this.qname;
	}

	public void setQname(String qname) {
		this.qname = qname;
	}

	public Integer getQa() {
		return this.qa;
	}

	public void setQa(Integer qa) {
		this.qa = qa;
	}

	public Integer getQb() {
		return this.qb;
	}

	public void setQb(Integer qb) {
		this.qb = qb;
	}

	public Integer getQc() {
		return this.qc;
	}

	public void setQc(Integer qc) {
		this.qc = qc;
	}

	public Integer getQd() {
		return this.qd;
	}

	public void setQd(Integer qd) {
		this.qd = qd;
	}

	public String getQchapter() {
		return this.qchapter;
	}

	public void setQchapter(String qchapter) {
		this.qchapter = qchapter;
	}

	public String getQta() {
		return this.qta;
	}

	public void setQta(String qta) {
		this.qta = qta;
	}

	public String getQtb() {
		return this.qtb;
	}

	public void setQtb(String qtb) {
		this.qtb = qtb;
	}

	public String getQtc() {
		return this.qtc;
	}

	public void setQtc(String qtc) {
		this.qtc = qtc;
	}

	public String getQtd() {
		return this.qtd;
	}

	public void setQtd(String qtd) {
		this.qtd = qtd;
	}

	public Set getTestPapersAnswerses() {
		return this.testPapersAnswerses;
	}

	public void setTestPapersAnswerses(Set testPapersAnswerses) {
		this.testPapersAnswerses = testPapersAnswerses;
	}

	public Set getTestPapersPaperses() {
		return this.testPapersPaperses;
	}

	public void setTestPapersPaperses(Set testPapersPaperses) {
		this.testPapersPaperses = testPapersPaperses;
	}

	public Set getPaperses() {
		return this.paperses;
	}

	public void setPaperses(Set paperses) {
		this.paperses = paperses;
	}

}