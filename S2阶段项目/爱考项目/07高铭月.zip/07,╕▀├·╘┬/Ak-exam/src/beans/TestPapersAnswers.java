package beans;

/**
 * TestPapersAnswers entity. @author MyEclipse Persistence Tools
 */

public class TestPapersAnswers implements java.io.Serializable {

	// Fields

	private Integer aid;
	private Questions questions;
	private TestPapersScore testPapersScore;
	private Integer qa;
	private Integer qb;
	private Integer qc;
	private Integer qd;

	// Constructors

	/** default constructor */
	public TestPapersAnswers() {
	}

	/** full constructor */
	public TestPapersAnswers(Questions questions, TestPapersScore testPapersScore, Integer qa, Integer qb, Integer qc,
			Integer qd) {
		this.questions = questions;
		this.testPapersScore = testPapersScore;
		this.qa = qa;
		this.qb = qb;
		this.qc = qc;
		this.qd = qd;
	}

	// Property accessors

	public Integer getAid() {
		return this.aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}

	public Questions getQuestions() {
		return this.questions;
	}

	public void setQuestions(Questions questions) {
		this.questions = questions;
	}

	public TestPapersScore getTestPapersScore() {
		return this.testPapersScore;
	}

	public void setTestPapersScore(TestPapersScore testPapersScore) {
		this.testPapersScore = testPapersScore;
	}

	public Integer getQa() {
		return this.qa;
	}

	public void setQa(Integer qa) {
		this.qa = qa;
	}

	public Integer getQb() {
		return this.qb;
	}

	public void setQb(Integer qb) {
		this.qb = qb;
	}

	public Integer getQc() {
		return this.qc;
	}

	public void setQc(Integer qc) {
		this.qc = qc;
	}

	public Integer getQd() {
		return this.qd;
	}

	public void setQd(Integer qd) {
		this.qd = qd;
	}

}