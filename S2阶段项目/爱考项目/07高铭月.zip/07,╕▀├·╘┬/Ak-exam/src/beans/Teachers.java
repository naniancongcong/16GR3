package beans;

/**
 * Teachers entity. @author MyEclipse Persistence Tools
 */

public class Teachers implements java.io.Serializable {

	// Fields

	private Integer tid;
	private TeachersType teachersType;
	private Accounts accounts;
	private String tname;
	private String tsex;
	private Long tbirthday;
	private String texp;
	private String ttel;
	private String tinfo;

	// Constructors

	/** default constructor */
	public Teachers() {
	}

	/** minimal constructor */
	public Teachers(TeachersType teachersType, Accounts accounts, String tname, String tsex, Long tbirthday,
			String texp, String ttel) {
		this.teachersType = teachersType;
		this.accounts = accounts;
		this.tname = tname;
		this.tsex = tsex;
		this.tbirthday = tbirthday;
		this.texp = texp;
		this.ttel = ttel;
	}

	/** full constructor */
	public Teachers(TeachersType teachersType, Accounts accounts, String tname, String tsex, Long tbirthday,
			String texp, String ttel, String tinfo) {
		this.teachersType = teachersType;
		this.accounts = accounts;
		this.tname = tname;
		this.tsex = tsex;
		this.tbirthday = tbirthday;
		this.texp = texp;
		this.ttel = ttel;
		this.tinfo = tinfo;
	}

	// Property accessors

	public Integer getTid() {
		return this.tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public TeachersType getTeachersType() {
		return this.teachersType;
	}

	public void setTeachersType(TeachersType teachersType) {
		this.teachersType = teachersType;
	}

	public Accounts getAccounts() {
		return this.accounts;
	}

	public void setAccounts(Accounts accounts) {
		this.accounts = accounts;
	}

	public String getTname() {
		return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getTsex() {
		return this.tsex;
	}

	public void setTsex(String tsex) {
		this.tsex = tsex;
	}

	public Long getTbirthday() {
		return this.tbirthday;
	}

	public void setTbirthday(Long tbirthday) {
		this.tbirthday = tbirthday;
	}

	public String getTexp() {
		return this.texp;
	}

	public void setTexp(String texp) {
		this.texp = texp;
	}

	public String getTtel() {
		return this.ttel;
	}

	public void setTtel(String ttel) {
		this.ttel = ttel;
	}

	public String getTinfo() {
		return this.tinfo;
	}

	public void setTinfo(String tinfo) {
		this.tinfo = tinfo;
	}

}