package beans;

/**
 * Actions entity. @author MyEclipse Persistence Tools
 */

public class Actions implements java.io.Serializable {

	// Fields

	private Integer aid;
	private Roles roles;
	private String aname;
	private String aurl;

	// Constructors

	/** default constructor */
	public Actions() {
	}

	/** full constructor */
	public Actions(Roles roles, String aname, String aurl) {
		this.roles = roles;
		this.aname = aname;
		this.aurl = aurl;
	}

	// Property accessors

	public Integer getAid() {
		return this.aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}

	public Roles getRoles() {
		return this.roles;
	}

	public void setRoles(Roles roles) {
		this.roles = roles;
	}

	public String getAname() {
		return this.aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}

	public String getAurl() {
		return this.aurl;
	}

	public void setAurl(String aurl) {
		this.aurl = aurl;
	}

}