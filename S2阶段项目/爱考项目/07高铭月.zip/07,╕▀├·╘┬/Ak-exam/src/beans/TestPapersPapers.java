package beans;

/**
 * TestPapersPapers entity. @author MyEclipse Persistence Tools
 */

public class TestPapersPapers implements java.io.Serializable {

	// Fields

	private Integer pid;
	private Questions questions;
	private TestPapers testPapers;

	// Constructors

	/** default constructor */
	public TestPapersPapers() {
	}

	/** full constructor */
	public TestPapersPapers(Questions questions, TestPapers testPapers) {
		this.questions = questions;
		this.testPapers = testPapers;
	}

	// Property accessors

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public Questions getQuestions() {
		return this.questions;
	}

	public void setQuestions(Questions questions) {
		this.questions = questions;
	}

	public TestPapers getTestPapers() {
		return this.testPapers;
	}

	public void setTestPapers(TestPapers testPapers) {
		this.testPapers = testPapers;
	}

}