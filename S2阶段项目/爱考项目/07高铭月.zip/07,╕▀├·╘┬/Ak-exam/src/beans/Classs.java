package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Classs entity. @author MyEclipse Persistence Tools
 */

public class Classs implements java.io.Serializable {

	// Fields

	private Integer cid;
	private String cname;
	private Set studentses = new HashSet(0);
	private Set testPapersClasses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Classs() {
	}

	/** minimal constructor */
	public Classs(String cname) {
		this.cname = cname;
	}

	/** full constructor */
	public Classs(String cname, Set studentses, Set testPapersClasses) {
		this.cname = cname;
		this.studentses = studentses;
		this.testPapersClasses = testPapersClasses;
	}

	// Property accessors

	public Integer getCid() {
		return this.cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public String getCname() {
		return this.cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public Set getStudentses() {
		return this.studentses;
	}

	public void setStudentses(Set studentses) {
		this.studentses = studentses;
	}

	public Set getTestPapersClasses() {
		return this.testPapersClasses;
	}

	public void setTestPapersClasses(Set testPapersClasses) {
		this.testPapersClasses = testPapersClasses;
	}

}