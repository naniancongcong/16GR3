package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import beans.Directions;
import beans.Stages;
import hb.HibernateSessionFactory;

public class StagesDao {
	public static List<Stages> getStagesByDirectionId(int id) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Stages.class);
		criteria.add(Restrictions.eq("directions.did", id));
		
		List<Stages> stages = (List<Stages>)criteria.getExecutableCriteria(session).list();
		session.close();
		return stages;
	}
}
