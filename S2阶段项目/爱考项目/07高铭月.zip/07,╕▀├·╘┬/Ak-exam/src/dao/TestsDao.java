package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import beans.Tests;
import hb.HibernateSessionFactory;

public class TestsDao {
	public static Tests getTestByTid(int tId) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Tests.class);
		criteria.add(Restrictions.eq("tid", tId));
		
		List<Tests> list = (List<Tests>)criteria.getExecutableCriteria(session).list();
		session.close();
		for (Tests test : list) {
			return test;
		}
		return null;
	}
	
	public static List<Tests> getTestByStageId(int sId) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Tests.class);
		criteria.add(Restrictions.eq("stages.sid", sId));
		
		List<Tests> stages = (List<Tests>)criteria.getExecutableCriteria(session).list();
		session.close();
		return stages;
	}
}
