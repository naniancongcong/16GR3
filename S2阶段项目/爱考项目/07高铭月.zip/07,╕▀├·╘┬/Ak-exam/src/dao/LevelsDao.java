package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import beans.Levels;
import hb.HibernateSessionFactory;

public class LevelsDao {
	public static Levels getLevelsByLname (String lname) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Levels.class);
		criteria.add(Restrictions.eq("lname", lname));
		
		List<Levels> list = (List<Levels>)criteria.getExecutableCriteria(session).list();
		session.close();
		
		for (Levels level : list) {
			return level;
		}
		
		return null;
	}
	
	public static List<Levels> getLevels () {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Levels.class);
		
		List<Levels> list = (List<Levels>)criteria.getExecutableCriteria(session).list();
		session.close();
		
		return list;
	}
}
