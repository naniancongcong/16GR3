package dao;

import java.util.Collections;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import beans.TestPapersPapers;
import hb.HibernateSessionFactory;

public class TestPapersPapersDao {
	public static boolean saveTestPapersPapers (TestPapersPapers testPapersPapers) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		try {
			session.save(testPapersPapers);
			transaction.commit();
		} catch (HibernateException e) {
			try {
				transaction.rollback();
			} catch (HibernateException e2) {
				session.close();
				return false;
			}
			session.close();
			return false;
		}
		return true;
	}
	
	public static int getTestPapersPapersCountByPeid (int pEid) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapersPapers.class);
		criteria.add(Restrictions.eq("testPapers.eid", pEid));
		criteria.setProjection(Projections.rowCount());
		int temp = Integer.parseInt(String.valueOf(criteria.getExecutableCriteria(session).uniqueResult()));
		session.close();
		return temp;
	}
	
	public static List<TestPapersPapers> getTestPapersPapersByPEId (int pEId) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapersPapers.class);
		
		criteria.add(Restrictions.eq("testPapers.eid", pEId));
		
		List<TestPapersPapers> testPapers = (List<TestPapersPapers>)criteria.getExecutableCriteria(session).list();
		
		Collections.shuffle(testPapers);
		
		session.close();
		return testPapers;
	}
}
