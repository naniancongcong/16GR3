package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import beans.Classs;
import hb.HibernateSessionFactory;

public class ClasssDao {
	public static List<Classs> getClasss() {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Classs.class);
		
		List<Classs> directions = (List<Classs>)criteria.getExecutableCriteria(session).list();
		session.close();
		return directions;
	}
}
