package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import beans.Roles;
import hb.HibernateSessionFactory;

public class RolesDao {
	public static String getRolesName (Roles role) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Roles.class);
		criteria.add(Restrictions.eq("rid", role.getRid()));
		
		List<Roles> roles = (List<Roles>)criteria.getExecutableCriteria(session).list();
		session.close();
		for (Roles r : roles) {
			return r.getRname();
		}
		return null;
	}
	
	public static List<Roles> getRoles () {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Roles.class);
		
		List<Roles> roles = (List<Roles>)criteria.getExecutableCriteria(session).list();
		
		session.close();
		return roles;
	}
}
