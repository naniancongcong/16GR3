package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import beans.Accounts;
import hb.HibernateSessionFactory;

public class AccountsDao {
	public static Integer login (Accounts account) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Accounts.class);
		criteria.add(Restrictions.eq("aname", account.getAname()));
		criteria.add(Restrictions.eq("apwd", account.getApwd()));
		criteria.add(Restrictions.eq("roles.rid", account.getRoles().getRid()));
		
		List<Accounts> accounts = (List<Accounts>)criteria.getExecutableCriteria(session).list();
		session.close();
		for (Accounts acc : accounts) {
			return acc.getAid();
		}
		return 0;
	}
}
