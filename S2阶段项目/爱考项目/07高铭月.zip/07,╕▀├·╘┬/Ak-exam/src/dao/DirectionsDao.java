package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import beans.Directions;
import hb.HibernateSessionFactory;

public class DirectionsDao {
	public static List<Directions> getDierctions() {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Directions.class);
		
		List<Directions> directions = (List<Directions>)criteria.getExecutableCriteria(session).list();
		session.close();
		return directions;
	}
}
