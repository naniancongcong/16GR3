package dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import beans.Questions;
import beans.TestPapers;
import beans.TestPapersClass;
import beans.TestPapersScore;
import hb.HibernateSessionFactory;

public class TestPapersClassDao {
	public static List<TestPapersClass> getTestPapersClassByCeid(int ceid) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapersClass.class);
		criteria.add(Restrictions.eq("testPapers.eid", ceid));
		
		List<TestPapersClass> testPapersClass = (List<TestPapersClass>)criteria.getExecutableCriteria(session).list();
		session.close();
		return testPapersClass;
	}
	
	public static TestPapersClass getTestPapersClassByCeidAndCcid(int ceid,int ccid) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapersClass.class);
		criteria.add(Restrictions.eq("testPapers.eid", ceid));
		criteria.add(Restrictions.eq("classs.cid", ccid));
		
		List<TestPapersClass> testPapersClasses = criteria.getExecutableCriteria(session).list();
		session.close();
		for (TestPapersClass testPapersClass : testPapersClasses) {
			return testPapersClass;
		}
		return null;
	}
	
	public static boolean saveTestPapersClass (TestPapersClass testPapersClass) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		try {
			session.save(testPapersClass);
			transaction.commit();
		} catch (HibernateException e) {
			try {
				transaction.rollback();
			} catch (HibernateException e2) {
				session.close();
				return false;
			}
			session.close();
			return false;
		}
		return true;
	}
	
	public static TestPapersClass getTestPapersClassByCCid (int cCId) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapersClass.class);
		criteria.add(Restrictions.eq("classs.cid", cCId));
		
		List<TestPapersClass> testPapersClasses = criteria.getExecutableCriteria(session).list();
		session.close();
		for (TestPapersClass testPapersClass : testPapersClasses) {
			return testPapersClass;
		}
		return null;
	}
}
