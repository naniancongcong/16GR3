package dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import beans.TestPapers;
import hb.HibernateSessionFactory;

public class TestPapersDao {
	public static List<TestPapers> getTestPapers () {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapers.class);
		
		List<TestPapers> testPapers = (List<TestPapers>)criteria.getExecutableCriteria(session).list();
		
		session.close();
		return testPapers;
	}
	
	public static List<TestPapers> getTestPapersByDirectionId (int did) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapers.class);
		
		criteria.createAlias("tests", "t");
		criteria.createAlias("t.stages", "s");
		criteria.createAlias("s.directions", "d");
		criteria.add(Restrictions.eq("d.did", did));
		
		List<TestPapers> testPapers = (List<TestPapers>)criteria.getExecutableCriteria(session).list();
		
		session.close();
		return testPapers;
	}
	
	public static List<TestPapers> getTestPapersByStageId (int sid) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapers.class);
		
		criteria.createAlias("tests", "t");
		criteria.createAlias("t.stages", "s");
		criteria.add(Restrictions.eq("s.sid", sid));
		
		List<TestPapers> testPapers = (List<TestPapers>)criteria.getExecutableCriteria(session).list();
		
		session.close();
		return testPapers;
	}
	
	public static List<TestPapers> getTestPapersByTestId (int tid) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapers.class);
		
		criteria.add(Restrictions.eq("tests.tid", tid));
		
		List<TestPapers> testPapers = (List<TestPapers>)criteria.getExecutableCriteria(session).list();
		
		session.close();
		return testPapers;
	}
	
	public static List<TestPapers> getTestPapers (int testType,int testStatus) {
		Long nowTime = System.currentTimeMillis();
		Session session = HibernateSessionFactory.getSession();
		String hql = "";
		
		if (testType != 0) {
			hql = "from TestPapers tp where tp.tests.tid in (select tid from Tests t where t.ttype=:ttype) ";
			if (testStatus == 1) {
				hql += "and tp.eid in (select tp1.eid from TestPapers tp1 where tp1.estart=0 and tp1.estatus!=1 or tp1.estart>" + nowTime + " and tp1.estatus=0 and tp1.eend=0)";
			}else if (testStatus == 2) {
				hql += "and tp.eid in (select tp1.eid from TestPapers tp1 where tp1.estart<=" + nowTime + " and " + nowTime + "<=(tp1.estart + tp1.etime) and tp1.estatus=0 and tp1.eend=0)";
			}else if (testStatus == 3) {
				hql += "and tp.eid in (select tp1.eid from TestPapers tp1 where tp1.estatus=1 or tp1.estart!=0 and (tp1.estart+tp1.etime)<=" + nowTime + " or tp1.eend!=0)";
			}
		}else {
			hql = "from TestPapers tp ";
			if (testStatus == 1) {
				hql += "where tp.estart=0 and tp.estatus!=1 or tp.estart>" + nowTime + " and tp.estatus=0 and tp.eend=0";
			}else if (testStatus == 2) {
				hql += "where tp.estart<=" + nowTime + " and " + nowTime + "<=(tp.estart + tp.etime) and tp.estatus=0 and tp.eend=0";
			}else if (testStatus == 3) {
				hql += "where tp.estatus=1 or tp.estart!=0 and (tp.estart+tp.etime)<=" + nowTime + " or tp.eend!=0";
			}
		}
		Query query = session.createQuery(hql);
		
		if (testType != 0) {
			query.setParameter("ttype", testType);
		}
		
		List<TestPapers> testPapers = query.list();
		
		session.close();
		return testPapers;
	}
	
	public static TestPapers saveTestPapers (TestPapers testPapers) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		try {
			session.save(testPapers);
			transaction.commit();
		} catch (HibernateException e) {
			try {
				transaction.rollback();
			} catch (HibernateException e2) {
				session.close();
			}
			session.close();
		}
		return testPapers;
	}
	
	public static boolean editTestPaper (TestPapers testPapers) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		try {
			session.update(testPapers);
			transaction.commit();
		} catch (HibernateException e) {
			try {
				transaction.rollback();
			} catch (HibernateException e2) {
				session.close();
				return false;
			}
			session.close();
			return false;
		}
		return true;
	}
	
	public static TestPapers getTestPaperByEid (int eId) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapers.class);
		criteria.add(Restrictions.eq("eid", eId));
		List<TestPapers> testpapers = criteria.getExecutableCriteria(session).list();
		session.close();
		for (TestPapers testPaper : testpapers) {
			return testPaper;
		}
		return null;
	}
}
