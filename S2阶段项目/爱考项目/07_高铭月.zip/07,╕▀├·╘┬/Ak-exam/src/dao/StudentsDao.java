package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import beans.Students;
import hb.HibernateSessionFactory;

public class StudentsDao {
	public static Students getStudentByAid (int aId) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Students.class);
		criteria.add(Restrictions.eq("accounts.aid", aId));
		
		List<Students> students = criteria.getExecutableCriteria(session).list();
		session.close();
		for (Students student : students) {
			return student;
		}
		return null;
	}
}
