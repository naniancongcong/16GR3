package dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import beans.TestPapersScore;
import hb.HibernateSessionFactory;

public class TestPapersScoreDao {
	public static List<TestPapersScore> getTestPapersScoresByCid(int cid) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapersScore.class);
		criteria.add(Restrictions.eq("testPapersClass.cid", cid));
		
		List<TestPapersScore> testPapersScores = (List<TestPapersScore>)criteria.getExecutableCriteria(session).list();
		session.close();
		return testPapersScores;
	}
	
	public static List<TestPapersScore> getTestPapersScoresBySsid(int sSid) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapersScore.class);
		criteria.add(Restrictions.eq("students.sid", sSid));
		
		List<TestPapersScore> testPapersScores = (List<TestPapersScore>)criteria.getExecutableCriteria(session).list();
		session.close();
		return testPapersScores;
	}
	
	public static TestPapersScore getTestPapersScoreBySid (int sId) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapersScore.class);
		criteria.add(Restrictions.eq("sid", sId));
		
		List<TestPapersScore> testPapersScores = criteria.getExecutableCriteria(session).list();
		session.close();
		for (TestPapersScore testPapersScore : testPapersScores) {
			return testPapersScore;
		}
		return null;
	}
	
	public static Integer saveTestPapersScore (TestPapersScore testPapersScore) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		int id = 0;
		try {
			id = (Integer)session.save(testPapersScore);
			transaction.commit();
		} catch (HibernateException e) {
			try {
				transaction.rollback();
			} catch (HibernateException e2) {
				session.close();
				return 0;
			}
			session.close();
			return 0;
		}
		return id;
	}
}
