package dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import beans.TestPapersAnswers;
import hb.HibernateSessionFactory;

public class TestPapersAnswersDao {
	public static List<TestPapersAnswers> getTestPapersAnswersBySid(int sid) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(TestPapersAnswers.class);
		criteria.add(Restrictions.eq("testPapersScore.sid", sid));
		
		List<TestPapersAnswers> testPapersScores = (List<TestPapersAnswers>)criteria.getExecutableCriteria(session).list();
		session.close();
		return testPapersScores;
	}
	
	public static Integer saveTestPapersAnswer (TestPapersAnswers testPapersAnswers) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		int id = 0;
		try {
			id = (Integer)session.save(testPapersAnswers);
			transaction.commit();
		} catch (HibernateException e) {
			try {
				transaction.rollback();
			} catch (HibernateException e2) {
				session.close();
				return 0;
			}
			session.close();
			return 0;
		}
		return id;
	}
}
