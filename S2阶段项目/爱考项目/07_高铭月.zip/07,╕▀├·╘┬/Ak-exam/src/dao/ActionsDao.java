package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import beans.Actions;
import hb.HibernateSessionFactory;

public class ActionsDao {
	public static List<Actions> getActionsByType (int type) {
		Session session = HibernateSessionFactory.getSession();
		
		DetachedCriteria criteria = DetachedCriteria.forClass(Actions.class);
		criteria.add(Restrictions.eq("roles.rid", type));
		
		List<Actions> actions = (List<Actions>) criteria.getExecutableCriteria(session).list();
		session.close();
		return actions;
	}
}
