package dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import beans.Questions;
import hb.HibernateSessionFactory;

public class QuestionsDao {
	public static int getQuestionsCountByQtid (int qTid) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Questions.class);
		criteria.add(Restrictions.eq("tests.tid", qTid));
		criteria.setProjection(Projections.rowCount());
		int temp = Integer.parseInt(String.valueOf(criteria.getExecutableCriteria(session).uniqueResult()));
		session.close();
		return temp;
	}
	
	public static List<Questions> getQuestionsByQtid (int qTid) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Questions.class);
		criteria.add(Restrictions.eq("tests.tid", qTid));
		
		List<Questions> questions = criteria.getExecutableCriteria(session).list();
		
		session.close();
		return questions;
	}
	
	public static Questions getQuestionByQid (int qId) {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Questions.class);
		criteria.add(Restrictions.eq("qid", qId));
		
		List<Questions> questions = criteria.getExecutableCriteria(session).list();
		session.close();
		for (Questions question : questions) {
			return question;
		}
		return null;
	}
	
	public static boolean saveQuestion (Questions question) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		try {
			session.save(question);
			transaction.commit();
		} catch (HibernateException e) {
			try {
				transaction.rollback();
			} catch (HibernateException e2) {
				session.close();
				return false;
			}
			session.close();
			return false;
		}
		return true;
	}
	
	public static boolean editQuestion (Questions question) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		try {
			session.update(question);
			transaction.commit();
		} catch (HibernateException e) {
			try {
				transaction.rollback();
			} catch (HibernateException e2) {
				session.close();
				return false;
			}
			session.close();
			return false;
		}
		return true;
	}
}
