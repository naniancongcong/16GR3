package actions;

import com.opensymphony.xwork2.ActionSupport;

import beans.Questions;
import dao.QuestionsDao;

public class QuestionAction extends ActionSupport {
	private Questions question;
	private Integer status;
	
	public String add() {
		init();
		if (QuestionsDao.saveQuestion(question)) {
			status = 1;
		}else {
			status = -1;
		}
		return "question_action";
	}
	
	public String edit() {
		init();
		question.setTests(QuestionsDao.getQuestionByQid(question.getQid()).getTests());
		if (QuestionsDao.editQuestion(question)) {
			status = 2;
		}else {
			status = -2;
		}
		return "question_action";
	}
	
	private void init() {
		if (question.getQa() == null) {
			question.setQa(0);
		}
		
		if (question.getQb() == null) {
			question.setQb(0);
		}
		
		if (question.getQc() == null) {
			question.setQc(0);
		}
		
		if (question.getQd() == null) {
			question.setQd(0);
		}
	}
	
	public Questions getQuestion() {
		return question;
	}

	public void setQuestion(Questions question) {
		this.question = question;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
}
