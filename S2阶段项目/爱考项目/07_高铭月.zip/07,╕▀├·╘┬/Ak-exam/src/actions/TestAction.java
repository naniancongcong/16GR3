package actions;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import beans.Accounts;
import beans.Questions;
import beans.Students;
import beans.TestPapers;
import beans.TestPapersAnswers;
import beans.TestPapersScore;
import dao.QuestionsDao;
import dao.StudentsDao;
import dao.TestPapersAnswersDao;
import dao.TestPapersClassDao;
import dao.TestPapersDao;
import dao.TestPapersScoreDao;

public class TestAction extends ActionSupport {
	private TestPapers testPapers;
	private TestPapersScore testPapersScore;
	private String addStatus;
	
	public String start() {
		Map<String, Object> map = ActionContext.getContext().getParameters();
		Set<String> set = map.keySet();
		int error = 0;
		ArrayList<TestPapersAnswers> answers = new ArrayList<TestPapersAnswers>();
		for (String key : set) {
			if (key.indexOf("answers") != -1) {
				Object[] objects = (Object[])map.get(key);
				Questions question = QuestionsDao.getQuestionByQid(Integer.parseInt(key.substring(key.indexOf("_") + 1, key.length())));
				TestPapersAnswers answer = new TestPapersAnswers();
				answer.setQuestions(question);
				for (Object o : objects) {
					if (Integer.parseInt(o.toString()) == 1) {
						answer.setQa(1);
						if (question.getQa() == 0 || question.getQb() == 1 || question.getQc() == 1 || question.getQd() == 1) {
							error++;
							break;
						}
					}else if (Integer.parseInt(o.toString()) == 2) {
						answer.setQb(1);
						if (question.getQb() == 0 || question.getQa() == 1 || question.getQc() == 1 || question.getQd() == 1) {
							error++;
							break;
						}
					}else if (Integer.parseInt(o.toString()) == 3) {
						answer.setQc(1);
						if (question.getQc() == 0 || question.getQa() == 1 || question.getQb() == 1 || question.getQd() == 1) {
							error++;
							break;
						}
					}else if (Integer.parseInt(o.toString()) == 4) {
						answer.setQd(1);
						if (question.getQd() == 0 || question.getQa() == 1 || question.getQb() == 1 || question.getQc() == 1) {
							error++;
							break;
						}
					}
				}
				answers.add(answer);
			}
		}
		Map<String, Object> session = ActionContext.getContext().getSession();
		Accounts account = (Accounts)session.get("login_user");
		Students student = StudentsDao.getStudentByAid(account.getAid());
		testPapersScore.setTestPapersClass(TestPapersClassDao.getTestPapersClassByCCid(student.getClasss().getCid()));
		testPapersScore.setStudents(student);
		testPapers = TestPapersDao.getTestPaperByEid(testPapers.getEid());
		int sscore = testPapers.getEscore() / answers.size() * (answers.size() - error);
		testPapersScore.setSscore(sscore);
		if (TestPapersScoreDao.saveTestPapersScore(testPapersScore) != 0) {
			for (TestPapersAnswers testPapersAnswers : answers) {
				if (testPapersAnswers.getQa() == null) {
					testPapersAnswers.setQa(0);
				}
				if (testPapersAnswers.getQb() == null) {
					testPapersAnswers.setQb(0);
				}
				if (testPapersAnswers.getQc() == null) {
					testPapersAnswers.setQc(0);
				}
				if (testPapersAnswers.getQd() == null) {
					testPapersAnswers.setQd(0);
				}
				testPapersAnswers.setTestPapersScore(testPapersScore);
				if (TestPapersAnswersDao.saveTestPapersAnswer(testPapersAnswers) == 0) {
					addStatus = "交卷失败！";
					return "test_end";
				}
			}
		}else {
			addStatus = "交卷失败！";
			return "test_end";
		}
		addStatus = "交卷成功！";
		return "test_end";
	}

	public TestPapers getTestPapers() {
		return testPapers;
	}

	public void setTestPapers(TestPapers testPapers) {
		this.testPapers = testPapers;
	}

	public TestPapersScore getTestPapersScore() {
		return testPapersScore;
	}

	public void setTestPapersScore(TestPapersScore testPapersScore) {
		this.testPapersScore = testPapersScore;
	}

	public String getAddStatus() {
		return addStatus;
	}

	public void setAddStatus(String addStatus) {
		this.addStatus = addStatus;
	}
}
