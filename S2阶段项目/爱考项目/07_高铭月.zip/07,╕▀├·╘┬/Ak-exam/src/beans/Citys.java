package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Citys entity. @author MyEclipse Persistence Tools
 */

public class Citys implements java.io.Serializable {

	// Fields

	private Integer cid;
	private Provides provides;
	private String cname;
	private Set studentses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Citys() {
	}

	/** minimal constructor */
	public Citys(Provides provides, String cname) {
		this.provides = provides;
		this.cname = cname;
	}

	/** full constructor */
	public Citys(Provides provides, String cname, Set studentses) {
		this.provides = provides;
		this.cname = cname;
		this.studentses = studentses;
	}

	// Property accessors

	public Integer getCid() {
		return this.cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public Provides getProvides() {
		return this.provides;
	}

	public void setProvides(Provides provides) {
		this.provides = provides;
	}

	public String getCname() {
		return this.cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public Set getStudentses() {
		return this.studentses;
	}

	public void setStudentses(Set studentses) {
		this.studentses = studentses;
	}

}