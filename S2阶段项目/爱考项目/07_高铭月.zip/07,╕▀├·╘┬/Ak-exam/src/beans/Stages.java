package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Stages entity. @author MyEclipse Persistence Tools
 */

public class Stages implements java.io.Serializable {

	// Fields

	private Integer sid;
	private Directions directions;
	private String sname;
	private Set courseses = new HashSet(0);
	private Set testses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Stages() {
	}

	/** minimal constructor */
	public Stages(Directions directions, String sname) {
		this.directions = directions;
		this.sname = sname;
	}

	/** full constructor */
	public Stages(Directions directions, String sname, Set courseses, Set testses) {
		this.directions = directions;
		this.sname = sname;
		this.courseses = courseses;
		this.testses = testses;
	}

	// Property accessors

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public Directions getDirections() {
		return this.directions;
	}

	public void setDirections(Directions directions) {
		this.directions = directions;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Set getCourseses() {
		return this.courseses;
	}

	public void setCourseses(Set courseses) {
		this.courseses = courseses;
	}

	public Set getTestses() {
		return this.testses;
	}

	public void setTestses(Set testses) {
		this.testses = testses;
	}

}