package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Tests entity. @author MyEclipse Persistence Tools
 */

public class Tests implements java.io.Serializable {

	// Fields

	private Integer tid;
	private Stages stages;
	private String tname;
	private Integer ttype;
	private Set testPaperses = new HashSet(0);
	private Set questionses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Tests() {
	}

	/** minimal constructor */
	public Tests(Stages stages, String tname, Integer ttype) {
		this.stages = stages;
		this.tname = tname;
		this.ttype = ttype;
	}

	/** full constructor */
	public Tests(Stages stages, String tname, Integer ttype, Set testPaperses, Set questionses) {
		this.stages = stages;
		this.tname = tname;
		this.ttype = ttype;
		this.testPaperses = testPaperses;
		this.questionses = questionses;
	}

	// Property accessors

	public Integer getTid() {
		return this.tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public Stages getStages() {
		return this.stages;
	}

	public void setStages(Stages stages) {
		this.stages = stages;
	}

	public String getTname() {
		return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public Integer getTtype() {
		return this.ttype;
	}

	public void setTtype(Integer ttype) {
		this.ttype = ttype;
	}

	public Set getTestPaperses() {
		return this.testPaperses;
	}

	public void setTestPaperses(Set testPaperses) {
		this.testPaperses = testPaperses;
	}

	public Set getQuestionses() {
		return this.questionses;
	}

	public void setQuestionses(Set questionses) {
		this.questionses = questionses;
	}

}