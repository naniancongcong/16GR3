package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * TeachersType entity. @author MyEclipse Persistence Tools
 */

public class TeachersType implements java.io.Serializable {

	// Fields

	private Integer tyid;
	private String tyname;
	private Set teacherses = new HashSet(0);

	// Constructors

	/** default constructor */
	public TeachersType() {
	}

	/** minimal constructor */
	public TeachersType(String tyname) {
		this.tyname = tyname;
	}

	/** full constructor */
	public TeachersType(String tyname, Set teacherses) {
		this.tyname = tyname;
		this.teacherses = teacherses;
	}

	// Property accessors

	public Integer getTyid() {
		return this.tyid;
	}

	public void setTyid(Integer tyid) {
		this.tyid = tyid;
	}

	public String getTyname() {
		return this.tyname;
	}

	public void setTyname(String tyname) {
		this.tyname = tyname;
	}

	public Set getTeacherses() {
		return this.teacherses;
	}

	public void setTeacherses(Set teacherses) {
		this.teacherses = teacherses;
	}

}