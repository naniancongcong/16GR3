package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * TestPapers entity. @author MyEclipse Persistence Tools
 */

public class TestPapers implements java.io.Serializable {

	// Fields

	private Integer eid;
	private Tests tests;
	private String ename;
	private Long estart;
	private Long etime;
	private Long eend;
	private Integer estatus;
	private Integer escore;
	private Set testPapersClasses = new HashSet(0);
	private Set paperses = new HashSet(0);
	private Set testPapersPaperses = new HashSet(0);

	// Constructors

	/** default constructor */
	public TestPapers() {
	}

	/** minimal constructor */
	public TestPapers(Tests tests, String ename, Long estart, Long etime, Long eend, Integer estatus, Integer escore) {
		this.tests = tests;
		this.ename = ename;
		this.estart = estart;
		this.etime = etime;
		this.eend = eend;
		this.estatus = estatus;
		this.escore = escore;
	}

	/** full constructor */
	public TestPapers(Tests tests, String ename, Long estart, Long etime, Long eend, Integer estatus, Integer escore,
			Set testPapersClasses, Set paperses, Set testPapersPaperses) {
		this.tests = tests;
		this.ename = ename;
		this.estart = estart;
		this.etime = etime;
		this.eend = eend;
		this.estatus = estatus;
		this.escore = escore;
		this.testPapersClasses = testPapersClasses;
		this.paperses = paperses;
		this.testPapersPaperses = testPapersPaperses;
	}

	// Property accessors

	public Integer getEid() {
		return this.eid;
	}

	public void setEid(Integer eid) {
		this.eid = eid;
	}

	public Tests getTests() {
		return this.tests;
	}

	public void setTests(Tests tests) {
		this.tests = tests;
	}

	public String getEname() {
		return this.ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public Long getEstart() {
		return this.estart;
	}

	public void setEstart(Long estart) {
		this.estart = estart;
	}

	public Long getEtime() {
		return this.etime;
	}

	public void setEtime(Long etime) {
		this.etime = etime;
	}

	public Long getEend() {
		return this.eend;
	}

	public void setEend(Long eend) {
		this.eend = eend;
	}

	public Integer getEstatus() {
		return this.estatus;
	}

	public void setEstatus(Integer estatus) {
		this.estatus = estatus;
	}

	public Integer getEscore() {
		return this.escore;
	}

	public void setEscore(Integer escore) {
		this.escore = escore;
	}

	public Set getTestPapersClasses() {
		return this.testPapersClasses;
	}

	public void setTestPapersClasses(Set testPapersClasses) {
		this.testPapersClasses = testPapersClasses;
	}

	public Set getPaperses() {
		return this.paperses;
	}

	public void setPaperses(Set paperses) {
		this.paperses = paperses;
	}

	public Set getTestPapersPaperses() {
		return this.testPapersPaperses;
	}

	public void setTestPapersPaperses(Set testPapersPaperses) {
		this.testPapersPaperses = testPapersPaperses;
	}

}