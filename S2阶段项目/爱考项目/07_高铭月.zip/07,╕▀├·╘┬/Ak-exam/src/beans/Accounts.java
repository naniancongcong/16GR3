package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Accounts entity. @author MyEclipse Persistence Tools
 */

public class Accounts implements java.io.Serializable {

	// Fields

	private Integer aid;
	private Roles roles;
	private String aname;
	private String apwd;
	private Set studentses = new HashSet(0);
	private Set teacherses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Accounts() {
	}

	/** minimal constructor */
	public Accounts(Roles roles, String aname, String apwd) {
		this.roles = roles;
		this.aname = aname;
		this.apwd = apwd;
	}

	/** full constructor */
	public Accounts(Roles roles, String aname, String apwd, Set studentses, Set teacherses) {
		this.roles = roles;
		this.aname = aname;
		this.apwd = apwd;
		this.studentses = studentses;
		this.teacherses = teacherses;
	}

	// Property accessors

	public Integer getAid() {
		return this.aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}

	public Roles getRoles() {
		return this.roles;
	}

	public void setRoles(Roles roles) {
		this.roles = roles;
	}

	public String getAname() {
		return this.aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}

	public String getApwd() {
		return this.apwd;
	}

	public void setApwd(String apwd) {
		this.apwd = apwd;
	}

	public Set getStudentses() {
		return this.studentses;
	}

	public void setStudentses(Set studentses) {
		this.studentses = studentses;
	}

	public Set getTeacherses() {
		return this.teacherses;
	}

	public void setTeacherses(Set teacherses) {
		this.teacherses = teacherses;
	}

}