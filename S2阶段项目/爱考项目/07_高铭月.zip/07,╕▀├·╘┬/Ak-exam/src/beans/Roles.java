package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Roles entity. @author MyEclipse Persistence Tools
 */

public class Roles implements java.io.Serializable {

	// Fields

	private Integer rid;
	private String rname;
	private Set accountses = new HashSet(0);
	private Set actionses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Roles() {
	}

	/** minimal constructor */
	public Roles(String rname) {
		this.rname = rname;
	}

	/** full constructor */
	public Roles(String rname, Set accountses, Set actionses) {
		this.rname = rname;
		this.accountses = accountses;
		this.actionses = actionses;
	}

	// Property accessors

	public Integer getRid() {
		return this.rid;
	}

	public void setRid(Integer rid) {
		this.rid = rid;
	}

	public String getRname() {
		return this.rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	public Set getAccountses() {
		return this.accountses;
	}

	public void setAccountses(Set accountses) {
		this.accountses = accountses;
	}

	public Set getActionses() {
		return this.actionses;
	}

	public void setActionses(Set actionses) {
		this.actionses = actionses;
	}

}