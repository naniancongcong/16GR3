package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Provides entity. @author MyEclipse Persistence Tools
 */

public class Provides implements java.io.Serializable {

	// Fields

	private Integer pid;
	private String pname;
	private Set studentses = new HashSet(0);
	private Set cityses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Provides() {
	}

	/** minimal constructor */
	public Provides(String pname) {
		this.pname = pname;
	}

	/** full constructor */
	public Provides(String pname, Set studentses, Set cityses) {
		this.pname = pname;
		this.studentses = studentses;
		this.cityses = cityses;
	}

	// Property accessors

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getPname() {
		return this.pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public Set getStudentses() {
		return this.studentses;
	}

	public void setStudentses(Set studentses) {
		this.studentses = studentses;
	}

	public Set getCityses() {
		return this.cityses;
	}

	public void setCityses(Set cityses) {
		this.cityses = cityses;
	}

}