package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Students entity. @author MyEclipse Persistence Tools
 */

public class Students implements java.io.Serializable {

	// Fields

	private Integer sid;
	private Rooms rooms;
	private Accounts accounts;
	private Classs classs;
	private Directions directions;
	private Provides provides;
	private Citys citys;
	private Skills skills;
	private String sname;
	private String ssex;
	private Long sintime;
	private Long sbirthday;
	private String sidcard;
	private String stel;
	private String sptel;
	private Integer sdid;
	private String sface;
	private String saddress;
	private String spinfo;
	private String sbaseinfo;
	private String sbackground;
	private Set testPapersScores = new HashSet(0);

	// Constructors

	/** default constructor */
	public Students() {
	}

	/** minimal constructor */
	public Students(Accounts accounts, Classs classs, String sname, String ssex, Long sintime) {
		this.accounts = accounts;
		this.classs = classs;
		this.sname = sname;
		this.ssex = ssex;
		this.sintime = sintime;
	}

	/** full constructor */
	public Students(Rooms rooms, Accounts accounts, Classs classs, Directions directions, Provides provides,
			Citys citys, Skills skills, String sname, String ssex, Long sintime, Long sbirthday, String sidcard,
			String stel, String sptel, Integer sdid, String sface, String saddress, String spinfo, String sbaseinfo,
			String sbackground, Set testPapersScores) {
		this.rooms = rooms;
		this.accounts = accounts;
		this.classs = classs;
		this.directions = directions;
		this.provides = provides;
		this.citys = citys;
		this.skills = skills;
		this.sname = sname;
		this.ssex = ssex;
		this.sintime = sintime;
		this.sbirthday = sbirthday;
		this.sidcard = sidcard;
		this.stel = stel;
		this.sptel = sptel;
		this.sdid = sdid;
		this.sface = sface;
		this.saddress = saddress;
		this.spinfo = spinfo;
		this.sbaseinfo = sbaseinfo;
		this.sbackground = sbackground;
		this.testPapersScores = testPapersScores;
	}

	// Property accessors

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public Rooms getRooms() {
		return this.rooms;
	}

	public void setRooms(Rooms rooms) {
		this.rooms = rooms;
	}

	public Accounts getAccounts() {
		return this.accounts;
	}

	public void setAccounts(Accounts accounts) {
		this.accounts = accounts;
	}

	public Classs getClasss() {
		return this.classs;
	}

	public void setClasss(Classs classs) {
		this.classs = classs;
	}

	public Directions getDirections() {
		return this.directions;
	}

	public void setDirections(Directions directions) {
		this.directions = directions;
	}

	public Provides getProvides() {
		return this.provides;
	}

	public void setProvides(Provides provides) {
		this.provides = provides;
	}

	public Citys getCitys() {
		return this.citys;
	}

	public void setCitys(Citys citys) {
		this.citys = citys;
	}

	public Skills getSkills() {
		return this.skills;
	}

	public void setSkills(Skills skills) {
		this.skills = skills;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSsex() {
		return this.ssex;
	}

	public void setSsex(String ssex) {
		this.ssex = ssex;
	}

	public Long getSintime() {
		return this.sintime;
	}

	public void setSintime(Long sintime) {
		this.sintime = sintime;
	}

	public Long getSbirthday() {
		return this.sbirthday;
	}

	public void setSbirthday(Long sbirthday) {
		this.sbirthday = sbirthday;
	}

	public String getSidcard() {
		return this.sidcard;
	}

	public void setSidcard(String sidcard) {
		this.sidcard = sidcard;
	}

	public String getStel() {
		return this.stel;
	}

	public void setStel(String stel) {
		this.stel = stel;
	}

	public String getSptel() {
		return this.sptel;
	}

	public void setSptel(String sptel) {
		this.sptel = sptel;
	}

	public Integer getSdid() {
		return this.sdid;
	}

	public void setSdid(Integer sdid) {
		this.sdid = sdid;
	}

	public String getSface() {
		return this.sface;
	}

	public void setSface(String sface) {
		this.sface = sface;
	}

	public String getSaddress() {
		return this.saddress;
	}

	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}

	public String getSpinfo() {
		return this.spinfo;
	}

	public void setSpinfo(String spinfo) {
		this.spinfo = spinfo;
	}

	public String getSbaseinfo() {
		return this.sbaseinfo;
	}

	public void setSbaseinfo(String sbaseinfo) {
		this.sbaseinfo = sbaseinfo;
	}

	public String getSbackground() {
		return this.sbackground;
	}

	public void setSbackground(String sbackground) {
		this.sbackground = sbackground;
	}

	public Set getTestPapersScores() {
		return this.testPapersScores;
	}

	public void setTestPapersScores(Set testPapersScores) {
		this.testPapersScores = testPapersScores;
	}

}