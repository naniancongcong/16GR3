package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * TestPapersScore entity. @author MyEclipse Persistence Tools
 */

public class TestPapersScore implements java.io.Serializable {

	// Fields

	private Integer sid;
	private Students students;
	private TestPapersClass testPapersClass;
	private Long sstart;
	private Long send;
	private Integer sscore;
	private Set testPapersAnswerses = new HashSet(0);

	// Constructors

	/** default constructor */
	public TestPapersScore() {
	}

	/** minimal constructor */
	public TestPapersScore(Students students, TestPapersClass testPapersClass, Long sstart, Long send, Integer sscore) {
		this.students = students;
		this.testPapersClass = testPapersClass;
		this.sstart = sstart;
		this.send = send;
		this.sscore = sscore;
	}

	/** full constructor */
	public TestPapersScore(Students students, TestPapersClass testPapersClass, Long sstart, Long send, Integer sscore,
			Set testPapersAnswerses) {
		this.students = students;
		this.testPapersClass = testPapersClass;
		this.sstart = sstart;
		this.send = send;
		this.sscore = sscore;
		this.testPapersAnswerses = testPapersAnswerses;
	}

	// Property accessors

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public Students getStudents() {
		return this.students;
	}

	public void setStudents(Students students) {
		this.students = students;
	}

	public TestPapersClass getTestPapersClass() {
		return this.testPapersClass;
	}

	public void setTestPapersClass(TestPapersClass testPapersClass) {
		this.testPapersClass = testPapersClass;
	}

	public Long getSstart() {
		return this.sstart;
	}

	public void setSstart(Long sstart) {
		this.sstart = sstart;
	}

	public Long getSend() {
		return this.send;
	}

	public void setSend(Long send) {
		this.send = send;
	}

	public Integer getSscore() {
		return this.sscore;
	}

	public void setSscore(Integer sscore) {
		this.sscore = sscore;
	}

	public Set getTestPapersAnswerses() {
		return this.testPapersAnswerses;
	}

	public void setTestPapersAnswerses(Set testPapersAnswerses) {
		this.testPapersAnswerses = testPapersAnswerses;
	}

}