package beans;

/**
 * Papers entity. @author MyEclipse Persistence Tools
 */

public class Papers implements java.io.Serializable {

	// Fields

	private Integer pid;
	private Questions questions;
	private TestPapers testPapers;

	// Constructors

	/** default constructor */
	public Papers() {
	}

	/** full constructor */
	public Papers(Questions questions, TestPapers testPapers) {
		this.questions = questions;
		this.testPapers = testPapers;
	}

	// Property accessors

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public Questions getQuestions() {
		return this.questions;
	}

	public void setQuestions(Questions questions) {
		this.questions = questions;
	}

	public TestPapers getTestPapers() {
		return this.testPapers;
	}

	public void setTestPapers(TestPapers testPapers) {
		this.testPapers = testPapers;
	}

}