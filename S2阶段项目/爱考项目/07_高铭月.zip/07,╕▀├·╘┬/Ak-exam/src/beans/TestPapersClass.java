package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * TestPapersClass entity. @author MyEclipse Persistence Tools
 */

public class TestPapersClass implements java.io.Serializable {

	// Fields

	private Integer cid;
	private Classs classs;
	private TestPapers testPapers;
	private Long cstart;
	private Set testPapersScores = new HashSet(0);

	// Constructors

	/** default constructor */
	public TestPapersClass() {
	}

	/** minimal constructor */
	public TestPapersClass(Classs classs, TestPapers testPapers, Long cstart) {
		this.classs = classs;
		this.testPapers = testPapers;
		this.cstart = cstart;
	}

	/** full constructor */
	public TestPapersClass(Classs classs, TestPapers testPapers, Long cstart, Set testPapersScores) {
		this.classs = classs;
		this.testPapers = testPapers;
		this.cstart = cstart;
		this.testPapersScores = testPapersScores;
	}

	// Property accessors

	public Integer getCid() {
		return this.cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public Classs getClasss() {
		return this.classs;
	}

	public void setClasss(Classs classs) {
		this.classs = classs;
	}

	public TestPapers getTestPapers() {
		return this.testPapers;
	}

	public void setTestPapers(TestPapers testPapers) {
		this.testPapers = testPapers;
	}

	public Long getCstart() {
		return this.cstart;
	}

	public void setCstart(Long cstart) {
		this.cstart = cstart;
	}

	public Set getTestPapersScores() {
		return this.testPapersScores;
	}

	public void setTestPapersScores(Set testPapersScores) {
		this.testPapersScores = testPapersScores;
	}

}